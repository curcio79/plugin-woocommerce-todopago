<?php
namespace TodoPago\Core\Address;
class GoogleAddressModel extends AddressModel
{	
	protected $hash;
	
	public function __construct(){
	}

	public function getGoogleData(){
		
	}

}

?>