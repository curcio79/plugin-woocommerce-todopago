<?php

/*
 * SILENCE IS GOLDEN... RETRIEVER
 */