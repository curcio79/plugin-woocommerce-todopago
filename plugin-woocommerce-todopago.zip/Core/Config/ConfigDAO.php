<?php
/**
 * Created by PhpStorm.
 * User: maximiliano
 * Date: 14/09/17
 * Time: 14:49
 */

namespace TodoPago\Core\Config;

class ConfigDAO extends \TodoPago\Core\AbstractClass\AbstractDAO
{

}