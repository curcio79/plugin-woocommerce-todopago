<?php

namespace TodoPago\Core\AbstractClass;
abstract class AbstractDAO
{

}


?>